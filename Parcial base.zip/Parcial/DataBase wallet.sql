CREATE TABLE Cards (
	ID int identity(1,1) primary key,
    CardNumber bigint,
    Name varchar(200),
    CVV int,
	ExpirationDate date,
	Bank varchar(50),
	Brand varchar(50)
);

CREATE PROCEDURE SaveCard
	@CardNumber bigint,
	@Name varchar(200),
    @CVV int,
	@ExpirationDate date,
	@Bank varchar(50),
	@Brand varchar(50)
AS
BEGIN
	INSERT INTO Cards (CardNumber, Name, CVV, ExpirationDate, Bank, Brand)
	VALUES (@CardNumber, @Name, @CVV, @ExpirationDate, @Bank, @Brand);
END
GO


CREATE PROCEDURE UpdateCard
	@ID int,
	@CardNumber bigint,
	@Name varchar(200),
    @CVV int,
	@ExpirationDate date,
	@Bank varchar(50),
	@Brand varchar(50)
AS
BEGIN
	UPDATE Cards
	SET CardNumber = @CardNumber, Name = @Name, CVV = @CVV, ExpirationDate = @ExpirationDate, Bank = @Bank, Brand = @Brand
	WHERE ID=@ID;
END
GO

CREATE PROCEDURE GetCards
AS
BEGIN
	SELECT * FROM Cards;
END
GO

CREATE PROCEDURE [dbo].[GetCard]
    @Id INT
AS
BEGIN
    SELECT *
    FROM Cards
    WHERE ID = @Id;
END


CREATE PROCEDURE DeleteCard
	@ID int
AS
BEGIN
	DELETE FROM Cards WHERE @ID = ID;
END
GO

INSERT INTO Cards (CardNumber, Name, CVV, ExpirationDate, Bank, Brand)
	VALUES (1234567891123456, 'Nombre Apellido', 111, '2023-10-23', 'BAC', 'Mastercard');

CREATE PROCEDURE spGetSearchedCard
	
	@search varchar(MAX)
AS
BEGIN
	SELECT 
		Bank,
		Brand, 
		ExpirationDate
	FROM Cards
	WHERE Bank LIKE '%' + @search + '%'
	OR Brand  LIKE '%' + @search + '%'
	OR ExpirationDate LIKE '%' + @search + '%'
END
GO